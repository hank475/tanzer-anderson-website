(() => {
  const menu = document.querySelector('.menu-toggle');
  const nav = document.querySelector('.primary-nav');
  menu?.addEventListener('click', () => {
    const open = nav.classList.toggle('open');
    document.body.classList.toggle('menu-open', open);
    menu.setAttribute('aria-expanded', String(open));
  });
  document.querySelectorAll('.nav-trigger').forEach(btn => btn.addEventListener('click', (e) => {
    if (window.matchMedia('(max-width:880px)').matches) {
      e.preventDefault();
      const group = btn.closest('.nav-group');
      const open = group.classList.toggle('open');
      btn.setAttribute('aria-expanded', String(open));
    }
  }));
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape') {
      nav?.classList.remove('open'); document.body.classList.remove('menu-open');
      menu?.setAttribute('aria-expanded','false');
      document.querySelectorAll('.nav-group.open').forEach(g => g.classList.remove('open'));
    }
  });

  const io = 'IntersectionObserver' in window ? new IntersectionObserver(entries => entries.forEach(entry => {
    if (entry.isIntersecting) { entry.target.classList.add('visible'); io.unobserve(entry.target); }
  }), {threshold:.07}) : null;
  document.querySelectorAll('.reveal').forEach(el => io ? io.observe(el) : el.classList.add('visible'));

  const notes = {
    command:'Current milestones, open actions, owners and the next decision—organized in one secure view.',
    market:'Target-company, talent-scarcity, compensation and location intelligence tailored to the active mandate.',
    evidence:'Evidence-led profiles, confidence levels and source context that support a defensible decision.',
    feedback:'Structured interview evidence, stakeholder calibration and clear follow-through without chasing status.',
    offer:'Offer strategy, competing-process context, acceptance risk and close support for the selected executive.',
    continuity:'Aftercare, integration checkpoints and relationship memory designed to preserve value after placement.'
  };
  document.querySelectorAll('.briefing-tab').forEach(btn => btn.addEventListener('click', () => {
    document.querySelectorAll('.briefing-tab').forEach(b => b.setAttribute('aria-selected','false'));
    btn.setAttribute('aria-selected','true');
    const note = document.querySelector('.briefing-note');
    if (note) note.textContent = notes[btn.dataset.note] || '';
  }));

  const openPreparedEmail = (data, status) => {
    const subject = encodeURIComponent(`Confidential website inquiry — ${data.organization || data.name || 'New inquiry'}`);
    const body = encodeURIComponent([
      `Full name: ${data.name || ''}`,
      `Title: ${data.title || ''}`,
      `Organization: ${data.organization || ''}`,
      `Work email: ${data.email || ''}`,
      `Phone: ${data.phone || ''}`,
      `Inquiry: ${data.inquiry || ''}`,
      '',
      data.message || ''
    ].join('\n'));
    if (status) status.textContent = 'A completed confidential inquiry is opening in your email application. Review and send it to finish the submission.';
    window.location.href = `mailto:director@tanzeranderson.com?subject=${subject}&body=${body}`;
  };

  document.querySelectorAll('.js-contact-form').forEach(form => form.addEventListener('submit', async event => {
    event.preventDefault();
    if (!form.reportValidity()) return;
    const data = Object.fromEntries(new FormData(form));
    const status = form.querySelector('.form-status');
    const button = form.querySelector('button[type="submit"]');
    const original = button?.textContent || 'Send confidentially';
    if (button) { button.disabled = true; button.textContent = 'Sending…'; }
    form.setAttribute('aria-busy', 'true');
    if (status) status.textContent = 'Sending your confidential inquiry…';
    try {
      const response = await fetch('/api/contact', {
        method: 'POST',
        headers: {'content-type': 'application/json'},
        body: JSON.stringify(data)
      });
      if (!response.ok) throw new Error('secure-endpoint-unavailable');
      form.reset();
      if (status) status.textContent = 'Your inquiry was delivered. Opening the confirmation page…';
      window.location.assign('/contact/received/');
    } catch (_) {
      openPreparedEmail(data, status);
    } finally {
      form.removeAttribute('aria-busy');
      if (button) { button.disabled = false; button.textContent = original; }
    }
  }));

})();
